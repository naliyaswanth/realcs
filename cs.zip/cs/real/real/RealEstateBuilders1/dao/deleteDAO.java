package com.RealEstateBuilders1.dao;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.RealEstateBuilders1.beans.BuildingInformationBean;
import com.RealEstateBuilders1.beans.RegisterBean;



public class deleteDAO  
{

	private HibernateTemplate ht;
	
	
	public void deleteDetails(RegisterBean rb) {
		
		System.out.println("insertEmp of EmpDAOImpl class.....");
        ht.delete(rb);
	}
	
	public void setHt(HibernateTemplate ht) {
        this.ht = ht;
    }

}
