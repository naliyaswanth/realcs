package com.RealEstateBuilders1.dao;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.RealEstateBuilders1.beans.BuildingInformationBean;



public class BuildingDAO  
{

	private HibernateTemplate ht;
	
	
	public void insertBuildingDetails(BuildingInformationBean bif) {
		
		System.out.println("insertEmp of EmpDAOImpl class.....");
        ht.saveOrUpdate(bif);
	}
	
	public void setHt(HibernateTemplate ht) {
        this.ht = ht;
    }

}
