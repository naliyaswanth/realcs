package com.RealEstateBuilders1.dao;

import com.RealEstateBuilders1.beans.RegisterBean;

public interface RegisterDAO {
	 void insertCustomer(RegisterBean rb);
}
