package com.RealEstateBuilders1.service;

import com.RealEstateBuilders1.beans.RegisterBean;

public interface RegisterService {
	void insertCustomer(RegisterBean rb);
}
