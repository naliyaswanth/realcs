package com.RealEstateBuilders1.service;

import java.util.List;

import com.RealEstateBuilders1.beans.RetriveBean;
import com.RealEstateBuilders1.dao.RetriveDAO;

public class RetriveService
{
	
		private RetriveDAO dao;
		
		public List validate(RetriveBean lb)
		{
			return dao.validate(lb);
			
		}
		
		public void setDao(RetriveDAO dao){
			this.dao=dao;
		}
		public RetriveDAO getDao(){
			return dao;
		}
		

	}


