package com.RealEstateBuilders1.controllers;

import  com.RealEstateBuilders1.beans.RegisterBean;
import com.RealEstateBuilders1.service.RegisterService;
import com.RealEstateBuilders1.service.RegisterServiceImplementation;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class RegisterController {

	@Autowired
    private RegisterService registerService;
	

    public void setRegisterService(RegisterService registerService) 
    {
    	System.out.println("RegisterController  setRegisterService method");
		this.registerService = registerService;
	}

	@RequestMapping(value="/insert.html", method = RequestMethod.POST)
    public ModelAndView insert(@ModelAttribute("cmdEmp") RegisterBean rb) 
    {
		
    	System.out.println("In Controller.....Before");
    	
    	registerService.insertCustomer(rb);
        
        System.out.println("In Controller.....After");
        
        return new ModelAndView("cusDetails");
    }

    
}
