package com.RealEstateBuilders1.beans;

import java.io.Serializable;

public class LoginBean implements Serializable{
	
	private String userName;
	private String passWord;
	private String role;
	
	
	public LoginBean()
	{
		
	}


	public LoginBean(String userName, String passWord) {
		super();
		this.setUserName(userName);
		this.setPassWord(passWord);
		this.setRole(role);
	}


	

	public String getPassWord() {
		return passWord;
	}


	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getRole() {
		return role;
	}


	public void setRole(String role) {
		this.role = role;
	}
	
	

}
