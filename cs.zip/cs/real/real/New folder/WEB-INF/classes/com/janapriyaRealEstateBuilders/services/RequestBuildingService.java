package com.janapriyaRealEstateBuilders.services;

import java.sql.SQLException;

import com.janapriyaRealEstateBuilders.beans.RequestBuilding;
import com.janapriyaRealEstateBuilders.daoimplementations.RequestBuildingDaoImplementation;
import com.janapriyaRealEstateBuilders.daointerfaces.RequestBuildingDao;

public class RequestBuildingService {

	public void requestABuilding(RequestBuilding requestBuilding) throws ClassNotFoundException,SQLException{
		// TODO Auto-generated method stub
		RequestBuildingDao requestBuildingDao =new RequestBuildingDaoImplementation();
	       
		 requestBuildingDao.requestABuilding(requestBuilding);
	}

	
}
