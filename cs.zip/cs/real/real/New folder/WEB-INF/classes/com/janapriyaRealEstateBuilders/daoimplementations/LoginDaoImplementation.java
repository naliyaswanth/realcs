package com.janapriyaRealEstateBuilders.daoimplementations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.janapriyaRealEstateBuilders.beans.Customer;
import com.janapriyaRealEstateBuilders.daointerfaces.LoginDao;
import com.janapriyaRealEstateBuilders.utilities.DatabaseConnectionUtility;

public class LoginDaoImplementation implements LoginDao {

	@Override
	
		public String validateUser(Customer login) throws ClassNotFoundException, SQLException{
	        String role = "";
	        Connection con = DatabaseConnectionUtility.getConnection();
	        PreparedStatement psmt = con.prepareStatement("select role from res_customer where username=? and password=? and status='approved'");
	        psmt.setString(1, login.getUserName());
	        psmt.setString(2, login.getPassword());
	        ResultSet rs = psmt.executeQuery();
	        if(rs.next()){
	            role=rs.getString("role");
	        }
	        else{
	            role = "invalid";
	        }
	        return role;
	    
		}

	}

