package com.janapriyaRealEstateBuilders.controllers;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.janapriyaRealEstateBuilders.beans.Customer;
import com.janapriyaRealEstateBuilders.services.CustomerService;

/**
 * Servlet implementation class UpdateProfileController
 */
public class UpdateProfileController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateProfileController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("inside update profile controller");
		String userName=request.getParameter("userName");
		String password=request.getParameter("password");
		String reEnterPassword=request.getParameter("reEnterPassword");
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String address=request.getParameter("address");
		String state=request.getParameter("state");
		String city=request.getParameter("city");
		String pin=request.getParameter("pin");
		String securityQuestion=request.getParameter("securityQuestion");
		String securityAnswer=request.getParameter("securityAnswer");
		
		
		Customer customer=new Customer();
		
		customer.setUserName(userName);
		customer.setPassword(password);
		customer.setFirstName(firstName);
		customer.setLastName(lastName);
		customer.setAddress(address);
		customer.setState(state);
		customer.setCity(city);
		customer.setPin(pin);
		customer.setSecurityQuestion(securityQuestion);
		customer.setSecurityAnswer(securityAnswer);
		
		CustomerService customerService=new CustomerService();
		try{
		       
			customerService.updateCustomerProfile(customer);
			       }
			       
			catch(ClassNotFoundException ce ){
			           
			ce.printStackTrace();
			           // append message to log file
			       }
			      
			 catch(SQLException se){
			           se.printStackTrace( );
			           // append message to log file
			       }
			     
			       
		    request.setAttribute("message", "Profile successfully updated!!!!");
			getServletContext().getRequestDispatcher("/UpdatedCustomerProfile.jsp").forward(request, response);
		
				
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
