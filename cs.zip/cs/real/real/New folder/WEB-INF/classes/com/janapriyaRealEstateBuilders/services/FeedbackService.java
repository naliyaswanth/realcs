package com.janapriyaRealEstateBuilders.services;

import java.sql.SQLException;

import com.janapriyaRealEstateBuilders.beans.Feedback;
import com.janapriyaRealEstateBuilders.daoimplementations.FeedbackDaoImplementation;
import com.janapriyaRealEstateBuilders.daointerfaces.FeedbackDao;


public class FeedbackService {
	public void sendFeedback(Feedback feedBack) throws ClassNotFoundException, SQLException{
	       
		 FeedbackDao feedbackDao =new FeedbackDaoImplementation();
		       
		 feedbackDao.sendFeedback(feedBack);

		    }

}
