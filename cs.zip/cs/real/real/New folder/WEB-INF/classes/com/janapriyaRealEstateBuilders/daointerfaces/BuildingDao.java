package com.janapriyaRealEstateBuilders.daointerfaces;

import java.sql.SQLException;

import com.janapriyaRealEstateBuilders.beans.Building;

public interface BuildingDao {

	public abstract void addNewBuilding(Building building) throws ClassNotFoundException, SQLException;

}
