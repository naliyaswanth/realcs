package com.janapriyaRealEstateBuilders.controllers;


import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.janapriyaRealEstateBuilders.beans.Customer;
import com.janapriyaRealEstateBuilders.exceptions.CustomerNotFoundException;
import com.janapriyaRealEstateBuilders.services.LoginService;

/**
 * Servlet implementation class LoginController
 */

public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String userName = request.getParameter("userName");
        String password = request.getParameter("password");
        String role = "";
        Customer loginInfo = new Customer( );
        loginInfo.setUserName(userName);
        loginInfo.setPassword(password);
        LoginService loginService = new LoginService( );
	
        try{
         role = loginService.validateUser(loginInfo);
        }
        catch(ClassNotFoundException ce){
            ce.printStackTrace();
           
        }
        catch(SQLException se){
            se.printStackTrace( );
            
        }
        if( role.equalsIgnoreCase("user")){
            HttpSession session = request.getSession();
            session.setAttribute("userName", userName);
            session.setAttribute("password", password);
            RequestDispatcher rd = request.getRequestDispatcher("/UserHome.jsp");
            session.setAttribute("message", "");
            rd.forward(request, response);
        }

        if( role.equalsIgnoreCase("admin")){
            HttpSession session = request.getSession();
            session.setAttribute("userName", userName);
           
            RequestDispatcher rd = request.getRequestDispatcher("/AdminHome.jsp");
            session.setAttribute("message", "");
            rd.forward(request, response);

        }

        if( role.equalsIgnoreCase("invalid")){
        	HttpSession session = request.getSession();
        	session.setAttribute("message", "invalid login id or password or status not approved");
            RequestDispatcher rd = request.getRequestDispatcher("/Login.jsp");
            rd.include(request, response);
        }
        }
        
        }
    
