
		package com.janapriyaRealEstateBuilders.controllers;

		import java.io.IOException;
		import java.sql.ResultSet;
		import java.sql.SQLException;

		import javax.servlet.ServletException;
		import javax.servlet.http.HttpServlet;
		import javax.servlet.http.HttpServletRequest;
		import javax.servlet.http.HttpServletResponse;
		import javax.servlet.http.HttpSession;

		import com.janapriyaRealEstateBuilders.beans.Customer;
		import com.janapriyaRealEstateBuilders.services.CustomerService;

		/**
		 * Servlet implementation class GetCustomerDetails
		 */
		public class AdminGetCustomerDetails extends HttpServlet {
			private static final long serialVersionUID = 1L;
		       
		    /**
		     * @see HttpServlet#HttpServlet()
		     */
		    public AdminGetCustomerDetails() {
		        super();
		        // TODO Auto-generated constructor stub
		    }

			/**
			 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
			 */
			protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				// TODO Auto-generated method stub
				System.out.println("inside customer controller");
				HttpSession session=request.getSession();
				String userName=request.getParameter("userName");
				String password=request.getParameter("password");
				String firstName=request.getParameter("firstName");
				String lastName=request.getParameter("lastName");
				String dateOfBirth=request.getParameter("dateOfBirth");
				String gender=request.getParameter("gender");
				String address=request.getParameter("address");
				String state=request.getParameter("state");
				String city=request.getParameter("city");
				String pin=request.getParameter("pin");
				String securityQuestion=request.getParameter("securityQuestion");
				String securityAnswer=request.getParameter("securityAnswer");
				String privilege=request.getParameter("privilege");
				String role=request.getParameter("role");
				String status=request.getParameter("status");
				
				Customer customer=new Customer();

				customer.setUserName(userName);
				customer.setPassword(password);
				customer.setFirstName(firstName);
				customer.setLastName(lastName);
				customer.setDateOfBirth(dateOfBirth);
				customer.setGender(gender);
				customer.setAddress(address);
				customer.setState(state);
				customer.setCity(city);
				customer.setPin(pin);
				customer.setSecurityQuestion(securityQuestion);
				customer.setSecurityAnswer(securityAnswer);
				customer.setPrivilege(privilege);
				customer.setStatus(status);
				customer.setRole(role);
				
				
				CustomerService customerService=new CustomerService();
				
				try{
				ResultSet rs=customerService.getCustomerDetailsAdmin(customer);
				//boolean flag=rs.next();
				if(rs.next()==true){
				session.setAttribute("userName",rs.getString(1));
				session.setAttribute("password",rs.getString(2));
				session.setAttribute("firstName",rs.getString(3));
				session.setAttribute("lastName",rs.getString(4));
				session.setAttribute("dateOfBirth",rs.getString(5));
				session.setAttribute("gender",rs.getString(6));
				session.setAttribute("address",rs.getString(7));
				session.setAttribute("city",rs.getString(8));
				session.setAttribute("state",rs.getString(9));
				session.setAttribute("pin",rs.getString(10));
				session.setAttribute("securityQuestion",rs.getString(11));
				session.setAttribute("securityAnswer",rs.getString(12));
				session.setAttribute("privilege",rs.getString(13));
				session.setAttribute("role",rs.getString(14));
				session.setAttribute("status",rs.getString(15));
				
				}
				System.out.println(userName);
				}
				catch(ClassNotFoundException ce ){
			           
					ce.printStackTrace();
					           // append message to log file
					       }
					      
					 catch(SQLException se){
					           se.printStackTrace( );
					           // append message to log file
					       }
				
				
				getServletContext().getRequestDispatcher("/AdminApproveCustomer.jsp").forward(request,response);
			}


			/**
			 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
			 */
			protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				// TODO Auto-generated method stub
				
		}
		}


