package com.janapriyaRealEstateBuilders.beans;
import java.io.Serializable;

public class Feedback implements Serializable{
	private String userName;
	private String feedback;
	public Feedback(){
		
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getFeedback() {
		return feedback;
	}
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

}
